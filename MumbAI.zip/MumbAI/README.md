# MumbAI — Your Travel Assistant

MumbAI is a Mumbai-focused travel assistant built with Flask, SQLite,
HTML, CSS and JavaScript. It combines on-device algorithms with one
live API.

## Architecture

- Flask serves the dashboard shell and Mumbai's stay data (seeded into `travel.db`).
- The browser performs all algorithmic reasoning locally.
- One live API: weather via Open-Meteo (no key required).

## Features

### Explore (algorithmic)
- Zone-based discovery: pick one or more of 6 Mumbai zones.
- **Greedy nearest-neighbour** — builds a walkable route from the
  user's first pick by repeatedly adding the closest unvisited place.
- **2-opt local search** — improves the ordering by reversing segments
  whenever the total distance gets shorter.

### Food Finder (algorithmic)
- **TOPSIS** (Technique for Order Preference by Similarity to Ideal
  Solution) — ranks restaurants by closeness to the ideal combination
  of area, dietary match, cuisine, budget and rating.

### Stays
- Curated Mumbai hotel, hostel and apartment catalogue.
- Ranked by rating, trust score, area, type and budget match.

### Weather (live API)
- Open-Meteo current conditions for Mumbai.
- Next 8 hours: temperature and rain chance per hour.
- No API key required.

### Aamchi AI (rule-based)
- Regex intent classifier routing questions to food, weather, stays,
  or explore.

## Data notes

- Booking URLs on the Stays tab point to public search pages.
- Weather data is live; everything else runs offline.

## Run

```powershell
py -m pip install -r requirements.txt
py seed_data.py
py app.py