DROP TABLE IF EXISTS countries;
DROP TABLE IF EXISTS cities;
DROP TABLE IF EXISTS places;
DROP TABLE IF EXISTS emergency_contacts;
DROP TABLE IF EXISTS hotels;
DROP TABLE IF EXISTS hotel_listings;
DROP TABLE IF EXISTS activities;
DROP TABLE IF EXISTS transport_stops;
DROP TABLE IF EXISTS transport_edges;
DROP TABLE IF EXISTS currency_rates;
DROP TABLE IF EXISTS phrases;
DROP TABLE IF EXISTS city_climate;

CREATE TABLE countries (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 code TEXT NOT NULL UNIQUE,
 currency_code TEXT NOT NULL
);
CREATE TABLE cities (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 country_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 state_name TEXT,
 latitude REAL NOT NULL,
 longitude REAL NOT NULL,
 FOREIGN KEY(country_id) REFERENCES countries(id)
);
CREATE TABLE places (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 category TEXT NOT NULL,
 name TEXT NOT NULL,
 x REAL NOT NULL,
 y REAL NOT NULL,
 description TEXT,
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
CREATE TABLE emergency_contacts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 country_id INTEGER,
 city_id INTEGER,
 service_name TEXT NOT NULL,
 number TEXT NOT NULL,
 FOREIGN KEY(country_id) REFERENCES countries(id),
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
CREATE TABLE hotels (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 type TEXT NOT NULL,
 price_per_night REAL NOT NULL,
 rating REAL NOT NULL,
 trust_score REAL NOT NULL,
 source_site TEXT NOT NULL,
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
CREATE TABLE hotel_listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 hotel_id INTEGER NOT NULL,
 website TEXT NOT NULL,
 price_per_night REAL NOT NULL,
 rating REAL NOT NULL,
 booking_url TEXT,
 FOREIGN KEY(hotel_id) REFERENCES hotels(id)
);
CREATE TABLE activities (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 cost REAL NOT NULL,
 mood_tags TEXT NOT NULL,
 description TEXT,
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
CREATE TABLE transport_stops (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 x REAL NOT NULL,
 y REAL NOT NULL,
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
CREATE TABLE transport_edges (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 from_stop_id INTEGER NOT NULL,
 to_stop_id INTEGER NOT NULL,
 mode TEXT NOT NULL,
 cost REAL NOT NULL,
 time_minutes REAL NOT NULL,
 FOREIGN KEY(city_id) REFERENCES cities(id),
 FOREIGN KEY(from_stop_id) REFERENCES transport_stops(id),
 FOREIGN KEY(to_stop_id) REFERENCES transport_stops(id)
);
CREATE TABLE currency_rates (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 currency_code TEXT NOT NULL UNIQUE,
 rate_to_usd REAL NOT NULL
);
CREATE TABLE phrases (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 language TEXT NOT NULL,
 phrase_key TEXT NOT NULL,
 english_text TEXT NOT NULL,
 translated_text TEXT NOT NULL
);
CREATE TABLE city_climate (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 city_id INTEGER NOT NULL,
 month INTEGER NOT NULL,
 avg_high_c REAL NOT NULL,
 avg_low_c REAL NOT NULL,
 rain_chance_percent REAL NOT NULL,
 notes TEXT,
 FOREIGN KEY(city_id) REFERENCES cities(id)
);
