import sqlite3

DB_PATH = "travel.db"


def run():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Rebuild the database from schema.sql
    with open("schema.sql", "r", encoding="utf-8") as f:
        cur.executescript(f.read())

    # ------------------------------------------------------------
    # Countries
    # ------------------------------------------------------------
    countries = [
        ("India", "IN", "INR"),
    ]
    cur.executemany(
        "INSERT INTO countries(name, code, currency_code) VALUES(?, ?, ?)",
        countries,
    )

    # ------------------------------------------------------------
    # Cities (Mumbai only — that's what the app uses)
    # ------------------------------------------------------------
    # country_id 1 = India
    cur.execute(
        "INSERT INTO cities(country_id, name, state_name, latitude, longitude) "
        "VALUES(?, ?, ?, ?, ?)",
        (1, "Mumbai", "Maharashtra", 19.0760, 72.8777),
    )
    mumbai_id = cur.lastrowid

    # ------------------------------------------------------------
    # Hotels
    # ------------------------------------------------------------
    hotels = [
        (mumbai_id, "The Taj Mahal Palace", "hotel", 25000, 4.8, 9.5, "Demo stay data"),
        (mumbai_id, "The Oberoi Mumbai", "hotel", 22000, 4.7, 9.4, "Demo stay data"),
        (mumbai_id, "The St. Regis Mumbai", "hotel", 18000, 4.7, 9.2, "Demo stay data"),
        (mumbai_id, "Taj Lands End", "hotel", 16000, 4.6, 9.1, "Demo stay data"),
        (mumbai_id, "Trident Nariman Point", "hotel", 14000, 4.6, 9.0, "Demo stay data"),
        (mumbai_id, "JW Marriott Mumbai Juhu", "hotel", 15000, 4.6, 9.0, "Demo stay data"),
        (mumbai_id, "Four Seasons Hotel Mumbai", "hotel", 17000, 4.6, 9.1, "Demo stay data"),
        (mumbai_id, "ITC Grand Central", "hotel", 11000, 4.5, 8.9, "Demo stay data"),
        (mumbai_id, "Residency Hotel Fort", "hotel", 3500, 4.4, 8.6, "Demo stay data"),
        (mumbai_id, "Fariyas Hotel Mumbai", "hotel", 5000, 4.2, 8.2, "Demo stay data"),
        (mumbai_id, "Hotel Marine Plaza", "hotel", 6500, 4.3, 8.4, "Demo stay data"),
        (mumbai_id, "President Mumbai", "hotel", 7000, 4.4, 8.5, "Demo stay data"),
        (mumbai_id, "Zostel Mumbai", "hostel", 900, 4.2, 7.5, "Demo stay data"),
        (mumbai_id, "Mumbai Backpackers Hostel", "hostel", 700, 4.1, 7.2, "Demo stay data"),
        (mumbai_id, "Bandra West Apartment", "apartment", 3200, 4.4, 8.3, "Demo stay data"),
        (mumbai_id, "Juhu Beach Apartment", "apartment", 4000, 4.3, 8.1, "Demo stay data"),
        (mumbai_id, "Colaba Heritage Apartment", "apartment", 4500, 4.4, 8.2, "Demo stay data"),
        (mumbai_id, "Andheri Private Apartment", "apartment", 2500, 4.2, 7.9, "Demo stay data"),
        (mumbai_id, "BKC Serviced Apartment", "serviced apartment", 5500, 4.4, 8.5, "Demo stay data"),
        (mumbai_id, "Powai Serviced Apartment", "serviced apartment", 4200, 4.3, 8.2, "Demo stay data"),
        (mumbai_id, "Andheri Guest House", "guest house", 1800, 4.0, 7.6, "Demo stay data"),
        (mumbai_id, "Near Airport Business Stay", "guest house", 2200, 4.1, 7.8, "Demo stay data"),
    ]
    cur.executemany(
        """
        INSERT INTO hotels
        (city_id, name, type, price_per_night, rating, trust_score, source_site)
        VALUES(?, ?, ?, ?, ?, ?, ?)
        """,
        hotels,
    )

    # ------------------------------------------------------------
    # Hotel listings (booking options shown in the Stay detail view)
    # ------------------------------------------------------------
    sites = [
        "Zostel official", "Booking.com", "MakeMyTrip",
        "Hostelworld", "Agoda", "Goibibo", "Expedia",
    ]
    factors = [1.00, 1.04, 0.98, 1.02, 1.06, 0.97, 1.08]

    cur.execute("SELECT id, price_per_night, rating FROM hotels")
    rows = cur.fetchall()

    listing_rows = []
    for hid, price, rating in rows:
        for k, site in enumerate(sites):
            adjusted_price = round(price * factors[k], 2)
            adjusted_rating = round(
                max(1, min(5, rating + ((k % 3) - 1) * 0.1)), 1
            )
            listing_rows.append(
                (hid, site, adjusted_price, adjusted_rating, "https://example.com/demo-booking")
            )

    cur.executemany(
        """
        INSERT INTO hotel_listings
        (hotel_id, website, price_per_night, rating, booking_url)
        VALUES(?, ?, ?, ?, ?)
        """,
        listing_rows,
    )

    conn.commit()
    conn.close()
    print("Database seeded successfully -> travel.db")


if __name__ == "__main__":
    run()