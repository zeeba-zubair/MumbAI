// ============================================================
// MumbAI — Landing screen
// Cosmetic "who's travelling" step. No accounts, no password —
// the name is only kept in this browser (localStorage) so the
// dashboard can greet the traveler by name.
// ============================================================

const nameInput = document.getElementById("traveler-name");
const continueBtn = document.getElementById("continue-btn");
const defaultCity = window.MumbAI_DEFAULT_CITY || null;

// Restore a previously entered name so returning visitors don't have to
// retype it.
const savedName = localStorage.getItem("MumbAIUserName");
if (savedName && nameInput) {
  nameInput.value = savedName;
}

function goToDashboard() {
  if (!defaultCity) return;

  const name = (nameInput.value || "").trim();

  if (name) {
    localStorage.setItem("MumbAIUserName", name);
  } else {
    localStorage.removeItem("MumbAIUserName");
  }

  localStorage.setItem(
    "currentCity",
    JSON.stringify({ id: defaultCity.id, name: defaultCity.name, state: defaultCity.state_name })
  );

  window.location.href = `/dashboard/${defaultCity.id}`;
}

if (continueBtn) {
  continueBtn.addEventListener("click", goToDashboard);
}

if (nameInput) {
  nameInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") goToDashboard();
  });
}