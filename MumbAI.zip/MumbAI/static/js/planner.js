// ============================================================
// MumbAI — Explore
//   Zones → pick places → nearest-neighbour + 2-opt
// ============================================================

(function initExplore() {
  "use strict";

  const DATA = window.MumbAI_DATA || {};
  const CITY_NAME = (DATA.city && DATA.city.name) || "Mumbai";

  // ------------------------------------------------------------
  // Categories
  // ------------------------------------------------------------
  const CATEGORIES = {
    heritage:  { label: "Heritage", color: "#8a6d3b" },
    religious: { label: "Sacred",   color: "#7a5c9e" },
    nature:    { label: "Nature",   color: "#3d7a4d" },
    market:    { label: "Markets",  color: "#a86b2e" },
    walk:      { label: "Walks",    color: "#4a6b4a" },
  };

  // ------------------------------------------------------------
  // Zones (6)
  // ------------------------------------------------------------
  const ZONES = {
    sobo:    "South Mumbai",
    central: "Central Mumbai",
    bandra:  "Bandra–Khar",
    juhu:    "Juhu–Andheri",
    suburbs: "Western Suburbs",
    powai:   "Powai",
  };

  const NEIGHBOURHOODS = [
    { name: "Borivali",  x: 8,  y: 15 },
    { name: "Malad",     x: 12, y: 25 },
    { name: "Goregaon",  x: 20, y: 30 },
    { name: "Andheri",   x: 22, y: 42 },
    { name: "Juhu",      x: 20, y: 48 },
    { name: "Bandra",    x: 26, y: 58 },
    { name: "Kurla",     x: 48, y: 44 },
    { name: "Powai",     x: 55, y: 32 },
    { name: "BKC",       x: 42, y: 52 },
    { name: "Dadar",     x: 55, y: 58 },
    { name: "Parel",     x: 52, y: 62 },
    { name: "Worli",     x: 44, y: 68 },
    { name: "Byculla",   x: 62, y: 55 },
    { name: "Fort",      x: 73, y: 62 },
    { name: "Colaba",    x: 79, y: 74 },
    { name: "Marine Dr", x: 60, y: 68 },
  ];

  // ------------------------------------------------------------
  // Places (6 zones, no day trips)
  // ------------------------------------------------------------
  const PLACES = [
    // South Mumbai
    { id: "p01", name: "Gateway of India",        cat: "heritage",  zone: "sobo",    x: 78, y: 72, cost: 0,   dur: 45  },
    { id: "p02", name: "CSMT",                    cat: "heritage",  zone: "sobo",    x: 72, y: 60, cost: 0,   dur: 30  },
    { id: "p04", name: "Rajabai Clock Tower",     cat: "heritage",  zone: "sobo",    x: 70, y: 63, cost: 0,   dur: 20  },
    { id: "p05", name: "Prince of Wales Museum",  cat: "heritage",  zone: "sobo",    x: 71, y: 65, cost: 100, dur: 90  },
    { id: "p06", name: "Jehangir Art Gallery",    cat: "walk",      zone: "sobo",    x: 72, y: 66, cost: 0,   dur: 60  },
    { id: "p07", name: "Bombay High Court",       cat: "heritage",  zone: "sobo",    x: 73, y: 62, cost: 0,   dur: 25  },
    { id: "p08", name: "Raj Bhavan",              cat: "heritage",  zone: "sobo",    x: 65, y: 60, cost: 0,   dur: 20  },
    { id: "p09", name: "Afghan Church",           cat: "heritage",  zone: "sobo",    x: 68, y: 42, cost: 0,   dur: 25  },
    { id: "p10", name: "St. Thomas Cathedral",    cat: "heritage",  zone: "sobo",    x: 73, y: 61, cost: 0,   dur: 20  },
    { id: "p12", name: "Sassoon Dock",            cat: "walk",      zone: "sobo",    x: 76, y: 74, cost: 0,   dur: 45  },
    { id: "p18", name: "Mumba Devi Temple",       cat: "religious", zone: "sobo",    x: 68, y: 58, cost: 0,   dur: 25  },
    { id: "p30", name: "Marine Drive",            cat: "walk",      zone: "sobo",    x: 60, y: 68, cost: 0,   dur: 60  },
    { id: "p31", name: "Girgaum Chowpatty",       cat: "nature",    zone: "sobo",    x: 62, y: 66, cost: 0,   dur: 45  },
    { id: "p37", name: "Colaba Causeway",         cat: "market",    zone: "sobo",    x: 80, y: 74, cost: 0,   dur: 90  },
    { id: "p38", name: "Crawford Market",         cat: "market",    zone: "sobo",    x: 74, y: 58, cost: 0,   dur: 60  },
    { id: "p42", name: "Fashion Street",          cat: "market",    zone: "sobo",    x: 63, y: 55, cost: 0,   dur: 60  },
    { id: "p44", name: "Zaveri Bazaar",           cat: "market",    zone: "sobo",    x: 67, y: 58, cost: 0,   dur: 60  },
    { id: "p45", name: "NCPA",                    cat: "walk",      zone: "sobo",    x: 62, y: 70, cost: 0,   dur: 90  },
    { id: "p47", name: "Regal Cinema",            cat: "walk",      zone: "sobo",    x: 79, y: 71, cost: 200, dur: 150 },
    { id: "p50", name: "NGMA",                    cat: "walk",      zone: "sobo",    x: 78, y: 72, cost: 150, dur: 75  },
    { id: "p52", name: "Fort Heritage Precinct",  cat: "walk",      zone: "sobo",    x: 73, y: 62, cost: 0,   dur: 90  },
    { id: "p53", name: "Ballard Estate",          cat: "walk",      zone: "sobo",    x: 75, y: 60, cost: 0,   dur: 60  },
    { id: "p54", name: "Kala Ghoda Art District", cat: "walk",      zone: "sobo",    x: 72, y: 64, cost: 0,   dur: 60  },
    { id: "p56", name: "Sassoon Docks walk",      cat: "walk",      zone: "sobo",    x: 76, y: 73, cost: 0,   dur: 60  },
    { id: "p67", name: "Fort heritage walk",      cat: "walk",      zone: "sobo",    x: 73, y: 62, cost: 500, dur: 120 },
    { id: "p68", name: "Kala Ghoda art walk",     cat: "walk",      zone: "sobo",    x: 72, y: 64, cost: 350, dur: 90  },
    { id: "p70", name: "Colaba food trail",       cat: "walk",      zone: "sobo",    x: 79, y: 73, cost: 700, dur: 120 },
    { id: "p72", name: "Mumbai by night tour",    cat: "walk",      zone: "sobo",    x: 60, y: 68, cost: 900, dur: 180 },

    // Central Mumbai
    { id: "p11", name: "Bhau Daji Lad Museum",    cat: "heritage",  zone: "central", x: 62, y: 55, cost: 100, dur: 75  },
    { id: "p13", name: "Haji Ali Dargah",         cat: "religious", zone: "central", x: 45, y: 68, cost: 0,   dur: 60  },
    { id: "p14", name: "Siddhivinayak Temple",    cat: "religious", zone: "central", x: 50, y: 62, cost: 0,   dur: 45  },
    { id: "p15", name: "Mahalaxmi Temple",        cat: "religious", zone: "central", x: 47, y: 65, cost: 0,   dur: 30  },
    { id: "p17", name: "Babulnath Temple",        cat: "religious", zone: "central", x: 55, y: 62, cost: 0,   dur: 25  },
    { id: "p22", name: "Hanging Gardens",         cat: "nature",    zone: "central", x: 58, y: 62, cost: 0,   dur: 45  },
    { id: "p23", name: "Kamala Nehru Park",       cat: "nature",    zone: "central", x: 58, y: 60, cost: 0,   dur: 40  },
    { id: "p29", name: "Worli Sea Face",          cat: "walk",      zone: "central", x: 44, y: 70, cost: 0,   dur: 40  },
    { id: "p39", name: "Chor Bazaar",             cat: "market",    zone: "central", x: 60, y: 55, cost: 0,   dur: 75  },
    { id: "p43", name: "Dadar Flower Market",     cat: "market",    zone: "central", x: 55, y: 58, cost: 0,   dur: 45  },
    { id: "p48", name: "Liberty Cinema",          cat: "walk",      zone: "central", x: 63, y: 56, cost: 200, dur: 150 },
    { id: "p49", name: "Royal Opera House",       cat: "walk",      zone: "central", x: 55, y: 60, cost: 0,   dur: 60  },
    { id: "p51", name: "Khotachiwadi",            cat: "walk",      zone: "central", x: 60, y: 63, cost: 0,   dur: 45  },
    { id: "p55", name: "Dharavi (guided)",        cat: "walk",      zone: "central", x: 55, y: 50, cost: 800, dur: 180 },
    { id: "p57", name: "Bandra–Worli Sea Link",   cat: "walk",      zone: "central", x: 38, y: 62, cost: 0,   dur: 30  },
    { id: "p58", name: "Malabar Hill",            cat: "nature",    zone: "central", x: 56, y: 64, cost: 0,   dur: 45  },
    { id: "p59", name: "Rajiv Gandhi viewpoint",  cat: "nature",    zone: "central", x: 36, y: 60, cost: 0,   dur: 20  },
    { id: "p69", name: "Dharavi photo walk",      cat: "walk",      zone: "central", x: 56, y: 51, cost: 600, dur: 150 },
    { id: "p71", name: "Chor Bazaar antiques",    cat: "walk",      zone: "central", x: 60, y: 55, cost: 300, dur: 75  },

    // Bandra–Khar
    { id: "p16", name: "Mount Mary Basilica",     cat: "religious", zone: "bandra",  x: 28, y: 55, cost: 0,   dur: 30  },
    { id: "p19", name: "St. Michael's Church",    cat: "religious", zone: "bandra",  x: 40, y: 55, cost: 0,   dur: 20  },
    { id: "p20", name: "Magen David Synagogue",   cat: "religious", zone: "bandra",  x: 63, y: 58, cost: 0,   dur: 25  },
    { id: "p24", name: "Joggers' Park",           cat: "nature",    zone: "bandra",  x: 25, y: 60, cost: 0,   dur: 30  },
    { id: "p27", name: "Bandra Bandstand",        cat: "nature",    zone: "bandra",  x: 27, y: 57, cost: 0,   dur: 45  },
    { id: "p28", name: "Carter Road Promenade",   cat: "walk",      zone: "bandra",  x: 26, y: 52, cost: 0,   dur: 45  },
    { id: "p40", name: "Linking Road",            cat: "market",    zone: "bandra",  x: 26, y: 55, cost: 0,   dur: 90  },
    { id: "p41", name: "Hill Road",               cat: "market",    zone: "bandra",  x: 27, y: 54, cost: 0,   dur: 60  },
    { id: "p66", name: "Bandstand walking tour",  cat: "walk",      zone: "bandra",  x: 27, y: 56, cost: 400, dur: 90  },

    // Juhu–Andheri
    { id: "p32", name: "Juhu Beach",              cat: "nature",    zone: "juhu",    x: 22, y: 45, cost: 0,   dur: 90  },
    { id: "p33", name: "Versova Beach",           cat: "nature",    zone: "juhu",    x: 18, y: 42, cost: 0,   dur: 75  },
    { id: "p36", name: "Marvé Beach",             cat: "nature",    zone: "juhu",    x: 14, y: 40, cost: 0,   dur: 60  },
    { id: "p46", name: "Prithvi Theatre",         cat: "walk",      zone: "juhu",    x: 20, y: 48, cost: 0,   dur: 90  },

    // Western Suburbs
    { id: "p21", name: "Sanjay Gandhi National Park", cat: "nature", zone: "suburbs", x: 32, y: 30, cost: 100, dur: 180 },
    { id: "p34", name: "Aksa Beach",              cat: "nature",    zone: "suburbs", x: 12, y: 38, cost: 0,   dur: 90  },
    { id: "p35", name: "Gorai Beach",             cat: "nature",    zone: "suburbs", x: 10, y: 32, cost: 0,   dur: 120 },

    // Powai
    { id: "p25", name: "Powai Lake",              cat: "nature",    zone: "powai",   x: 55, y: 32, cost: 0,   dur: 60  },
    { id: "p26", name: "Vihar Lake",              cat: "nature",    zone: "powai",   x: 48, y: 28, cost: 0,   dur: 60  },
  ];

  const byId = Object.fromEntries(PLACES.map(p => [p.id, p]));

  // ------------------------------------------------------------
  // State
  // ------------------------------------------------------------
  const state = {
    view: "zones",
    selectedZones: new Set(),
    picks: [],
  };

  // ------------------------------------------------------------
  // DOM handles
  // ------------------------------------------------------------
  const gZones     = document.getElementById("planner-map-zones");
  const gEdges     = document.getElementById("planner-map-edges");
  const gNodes     = document.getElementById("planner-map-nodes");
  const ticker     = document.getElementById("planner-ticker");
  const plansPanel = document.getElementById("planner-days-panel");

  // ------------------------------------------------------------
  // Projection
  // ------------------------------------------------------------
  const PAD = 50;
  const VW = 800, VH = 620;

  let projBounds = { minX: 0, maxX: 100, minY: 0, maxY: 100 };

  function updateProjection() {
    const visible = PLACES.filter(p => state.selectedZones.has(p.zone));

    if (visible.length === 0) {
      projBounds = { minX: 0, maxX: 100, minY: 0, maxY: 100 };
      return;
    }

    const xs = visible.map(p => p.x);
    const ys = visible.map(p => p.y);
    const pad = 6;

    projBounds = {
      minX: Math.max(0, Math.min(...xs) - pad),
      maxX: Math.min(100, Math.max(...xs) + pad),
      minY: Math.max(0, Math.min(...ys) - pad),
      maxY: Math.min(100, Math.max(...ys) + pad),
    };
  }

  function px(x) {
    const range = projBounds.maxX - projBounds.minX || 1;
    return PAD + ((x - projBounds.minX) / range) * (VW - 2 * PAD);
  }

  function py(y) {
    const range = projBounds.maxY - projBounds.minY || 1;
    return PAD + ((y - projBounds.minY) / range) * (VH - 2 * PAD);
  }

  // ------------------------------------------------------------
  // Utilities
  // ------------------------------------------------------------
  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

  function routeLength(ids) {
    if (ids.length < 2) return 0;
    let total = 0;
    for (let i = 1; i < ids.length; i++) total += dist(byId[ids[i - 1]], byId[ids[i]]);
    return total;
  }

  const totalCost    = ids => ids.reduce((s, id) => s + (byId[id]?.cost || 0), 0);
  const totalMinutes = ids => ids.reduce((s, id) => s + (byId[id]?.dur  || 0), 0);
  const gridToKm     = units => units * 0.15;

  function flashTicker(msg) {
    if (!ticker) return;
    ticker.textContent = msg;
    ticker.classList.add("flash");
    setTimeout(() => ticker.classList.remove("flash"), 900);
  }

  const escHtml = s =>
    String(s).replace(/[&<>"']/g, c =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
    );

  // ------------------------------------------------------------
  // Algorithm 1: nearest-neighbour
  // ------------------------------------------------------------
  function nearestNeighbour(ids) {
    if (ids.length < 2) return ids.slice();

    const remaining = new Set(ids);
    const route = [ids[0]];
    remaining.delete(ids[0]);

    while (remaining.size > 0) {
      const last = byId[route[route.length - 1]];
      let closest = null, closestDist = Infinity;
      remaining.forEach(id => {
        const d = dist(last, byId[id]);
        if (d < closestDist) { closestDist = d; closest = id; }
      });
      route.push(closest);
      remaining.delete(closest);
    }
    return route;
  }

  // ------------------------------------------------------------
  // Algorithm 2: 2-opt
  // ------------------------------------------------------------
  function twoOpt(ids) {
    if (ids.length < 4) return ids.slice();

    let best = ids.slice();
    let bestLen = routeLength(best);
    let improved = true;
    let guard = 0;

    while (improved && guard++ < 30) {
      improved = false;
      for (let i = 1; i < best.length - 2; i++) {
        for (let j = i + 1; j < best.length - 1; j++) {
          const candidate = best.slice(0, i)
            .concat(best.slice(i, j + 1).reverse())
            .concat(best.slice(j + 1));
          const len = routeLength(candidate);
          if (len < bestLen - 1e-6) {
            best = candidate;
            bestLen = len;
            improved = true;
          }
        }
      }
    }
    return best;
  }

  // ------------------------------------------------------------
  // Zone picker
  // ------------------------------------------------------------
  function renderZonePills() {
    const grid = document.getElementById("zone-pill-grid");
    if (!grid) return;

    grid.innerHTML = Object.entries(ZONES).map(([key, name]) => {
      const selected = state.selectedZones.has(key);
      return `
        <button class="zone-pill ${selected ? "selected" : ""}" data-zone="${key}">
          ${escHtml(name)}
        </button>
      `;
    }).join("");

    grid.querySelectorAll(".zone-pill").forEach(pill => {
      pill.addEventListener("click", () => {
        const zone = pill.dataset.zone;
        if (state.selectedZones.has(zone)) state.selectedZones.delete(zone);
        else state.selectedZones.add(zone);
        renderZonePills();
        updateContinueState();
      });
    });
  }

  function updateContinueState() {
    const btn = document.getElementById("zone-continue-btn");
    if (!btn) return;
    btn.disabled = state.selectedZones.size === 0;
  }

  function enterPlannerView() {
    if (state.selectedZones.size === 0) return;
    state.view = "planner";
    document.getElementById("zone-picker-view").classList.add("hidden");
    document.getElementById("planner-view").classList.remove("hidden");
    renderAll();
  }

  function leavePlannerView() {
    state.view = "zones";
    document.getElementById("planner-view").classList.add("hidden");
    document.getElementById("zone-picker-view").classList.remove("hidden");
  }

  // ------------------------------------------------------------
  // Rendering — map
  // ------------------------------------------------------------
  function renderZones() {
    if (!gZones) return;

    const visibleLabels = NEIGHBOURHOODS.filter(z =>
      z.x >= projBounds.minX && z.x <= projBounds.maxX &&
      z.y >= projBounds.minY && z.y <= projBounds.maxY
    );

    gZones.innerHTML = visibleLabels.map(z => `
      <text class="map-zone-label" x="${px(z.x)}" y="${py(z.y)}">${escHtml(z.name)}</text>
    `).join("");
  }

  function renderLegend() {
    const legend = document.getElementById("planner-map-legend");
    if (!legend) return;

    const used = new Set();
    state.picks.forEach(id => used.add(byId[id].cat));
    PLACES.forEach(p => {
      if (state.selectedZones.has(p.zone)) used.add(p.cat);
    });

    legend.innerHTML = [...used].map(cat => `
      <span><i style="background:${CATEGORIES[cat].color}"></i>${CATEGORIES[cat].label}</span>
    `).join("");
  }

  function renderNodes() {
    if (!gNodes) return;

    const picked = new Set(state.picks);
    const visible = PLACES.filter(p => state.selectedZones.has(p.zone));

    gNodes.innerHTML = visible.map(p => {
      const isPicked = picked.has(p.id);
      const fill = CATEGORIES[p.cat]?.color || "#a8b0aa";
      const r = isPicked ? 9 : 6;
      const stroke = isPicked ? "#1e40af" : "#fff";
      const strokeWidth = isPicked ? 3 : 1.2;

      return `
        <circle class="map-node" data-place="${p.id}"
          cx="${px(p.x)}" cy="${py(p.y)}" r="${r}"
          fill="${fill}" stroke="${stroke}" stroke-width="${strokeWidth}">
          <title>${escHtml(p.name)}</title>
        </circle>
      `;
    }).join("");

    gNodes.querySelectorAll(".map-node").forEach(node => {
      node.addEventListener("mouseenter", () => {
        const p = byId[node.dataset.place];
        ticker.textContent = `${p.name} · ${CATEGORIES[p.cat].label} · ₹${p.cost} · ${p.dur} min`;
      });
      node.addEventListener("mouseleave", () => {
        ticker.textContent = defaultTicker();
      });
      node.addEventListener("click", e => {
        e.stopPropagation();
        togglePick(node.dataset.place);
      });
    });
  }

  function renderEdges() {
    if (!gEdges) return;
    if (state.picks.length < 2) { gEdges.innerHTML = ""; return; }

    const pts = state.picks.map(id => `${px(byId[id].x)},${py(byId[id].y)}`).join(" ");
    gEdges.innerHTML = `<polyline class="map-edge" points="${pts}"
      stroke="#1e40af" stroke-width="2.5" opacity="0.85" />`;
  }

  // ------------------------------------------------------------
  // Rendering — Plans panel
  // ------------------------------------------------------------
  function renderPlansPanel() {
    if (!plansPanel) return;

    const km = gridToKm(routeLength(state.picks)).toFixed(1);
    const cost = totalCost(state.picks);
    const mins = totalMinutes(state.picks);

    const rows = state.picks.length
      ? state.picks.map((id, i) => renderPickRow(id, i)).join("")
      : `<div class="planner-empty-slot">
           No places yet
           <div style="margin-top:6px;font-size:0.65rem;opacity:0.7;letter-spacing:0.04em;">
             Tap dots on the map
           </div>
         </div>`;

    plansPanel.innerHTML = `
      <div class="planner-day-col">
        <div class="planner-day-head">
          <div class="planner-day-head-top">
            <span class="planner-day-dot" style="background:#1e40af"></span>
            <span class="planner-day-name">PLANS</span>
          </div>
          <div class="planner-day-meta">
            <span>${state.picks.length} pick${state.picks.length === 1 ? "" : "s"}</span>
            <span>${km} km</span>
            <span>${mins}m</span>
            <span>₹${cost}</span>
          </div>
        </div>
        <div class="planner-day-body">
          ${rows}
        </div>
      </div>
    `;

    plansPanel.querySelectorAll(".place-chip-remove").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        togglePick(btn.dataset.place);
      });
    });
  }

  function renderPickRow(id, index) {
    const p = byId[id];
    if (!p) return "";
    const cat = CATEGORIES[p.cat]?.label || p.cat;
    return `
      <div class="place-chip" data-place="${id}">
        <div class="place-chip-bar" style="background:${CATEGORIES[p.cat].color}"></div>
        <div class="place-chip-body">
          <div class="place-chip-name">${index + 1}. ${escHtml(p.name)}</div>
          <div class="place-chip-meta">
            <span class="place-chip-cat">${escHtml(cat)}</span>
            <span>₹${p.cost}</span>
            <span>${p.dur}m</span>
          </div>
        </div>
        <button class="place-chip-remove" data-place="${id}" title="Remove">×</button>
      </div>
    `;
  }

  // ------------------------------------------------------------
  // Picks
  // ------------------------------------------------------------
  function togglePick(id) {
    const i = state.picks.indexOf(id);
    if (i === -1) {
      state.picks.push(id);
      flashTicker(`${byId[id].name} added`);
    } else {
      state.picks.splice(i, 1);
      flashTicker(`${byId[id].name} removed`);
    }
    renderAll();
  }

  // ------------------------------------------------------------
  // Ticker
  // ------------------------------------------------------------
  function defaultTicker() {
    if (state.picks.length === 0) {
      const zoneCount = state.selectedZones.size;
      return zoneCount > 0
        ? "Tap coloured dots to add places. Colours = category."
        : "Pick a zone to begin.";
    }
    return `${state.picks.length} place${state.picks.length === 1 ? "" : "s"} picked · Hit SORT ROUTE to reorder`;
  }

  // ------------------------------------------------------------
  // Main render
  // ------------------------------------------------------------
  function renderAll() {
    if (state.view !== "planner") return;

    updateProjection();
    renderZones();
    renderLegend();
    renderEdges();
    renderNodes();
    renderPlansPanel();

    if (ticker) ticker.textContent = defaultTicker();
  }

  // ------------------------------------------------------------
  // Button handlers
  // ------------------------------------------------------------
  const continueBtn = document.getElementById("zone-continue-btn");
  if (continueBtn) continueBtn.addEventListener("click", enterPlannerView);

  const changeZonesBtn = document.getElementById("change-zones-btn");
  if (changeZonesBtn) changeZonesBtn.addEventListener("click", leavePlannerView);

  // SORT ROUTE
  const optimizeBtn = document.getElementById("planner-optimize-btn");
  if (optimizeBtn) {
    optimizeBtn.addEventListener("click", () => {
      if (state.picks.length < 2) {
        flashTicker("Pick at least 2 places first");
        return;
      }
      const before = routeLength(state.picks);
      const sorted = twoOpt(nearestNeighbour(state.picks));
      state.picks = sorted;
      const after = routeLength(state.picks);
      const savedKm = gridToKm(before - after).toFixed(1);

      flashTicker(
        savedKm > 0
          ? `Sorted · saved ~${savedKm} km`
          : "Route already optimal"
      );
      renderAll();
    });
  }

  // SUGGEST
  const suggestBtn = document.getElementById("planner-suggest-btn");
  if (suggestBtn) {
    suggestBtn.addEventListener("click", () => {
      const pool = PLACES.filter(p => state.selectedZones.has(p.zone));
      if (pool.length === 0) {
        flashTicker("No places in the selected zones");
        return;
      }

      if (state.picks.length === 0) {
        flashTicker("Tap a dot to start, then we'll build a route around it");
        return;
      }

      const seed = state.picks[0];
      const chosen = [seed];
      const remaining = new Set(pool.filter(p => p.id !== seed).map(p => p.id));

      while (chosen.length < 4 && remaining.size > 0) {
        const last = byId[chosen[chosen.length - 1]];
        let closest = null, closestDist = Infinity;
        remaining.forEach(id => {
          const d = dist(last, byId[id]);
          if (d < closestDist) { closestDist = d; closest = id; }
        });
        chosen.push(closest);
        remaining.delete(closest);
      }

      state.picks = twoOpt(nearestNeighbour(chosen));

      const km = gridToKm(routeLength(state.picks)).toFixed(1);
      flashTicker(`Built a ${state.picks.length}-stop walk · ${km} km`);
      renderAll();
    });
  }

  // RESET
  const clearBtn = document.getElementById("planner-clear-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      state.picks = [];
      flashTicker("Cleared");
      renderAll();
    });
  }

  // ------------------------------------------------------------
  // Init
  // ------------------------------------------------------------
  const cityLabel = document.getElementById("planner-city-label");
  if (cityLabel) cityLabel.textContent = CITY_NAME.toUpperCase();

  renderZonePills();
  updateContinueState();
  renderAll();

  window.__MumbAIExplore = { state, PLACES, twoOpt, nearestNeighbour };
})();