// ============================================================
// MumbAI Dashboard
// ============================================================

const DATA = window.MumbAI_DATA || {};
const city = DATA.city || null;

if (!city) {
  window.location.href = "/";
}

const currentCityNameEl = document.getElementById("current-city-name");
if (currentCityNameEl) currentCityNameEl.textContent = city.name;

const changeCityBtn = document.getElementById("change-city-btn");
if (changeCityBtn) {
  changeCityBtn.addEventListener("click", () => {
    window.location.href = "/";
  });
}

// ============================================================
// Tab switching
// ============================================================

const mainEl = document.querySelector("main");

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));

    btn.classList.add("active");
    const panel = document.getElementById(`tab-${btn.dataset.tab}`);
    if (panel) panel.classList.add("active");

    if (mainEl) {
      if (btn.dataset.tab === "map") mainEl.classList.add("planner-wide");
      else mainEl.classList.remove("planner-wide");
    }
  });
});

if (mainEl) mainEl.classList.add("planner-wide");

// ============================================================
// STAYS
// ============================================================

const hotelDetail = document.getElementById("hotel-detail");
const hotelDetailContent = document.getElementById("hotel-detail-content");
const hotelListings = document.getElementById("hotel-listings");
const listingSortWrap = document.getElementById("hotel-listing-sort-wrap");
const listingSort = document.getElementById("hotel-listing-sort");

const stayAreaFilter = document.getElementById("stay-area-filter");
const stayTypeFilter = document.getElementById("stay-type-filter");
const stayBudgetFilter = document.getElementById("stay-budget-filter");
const stayResultCount = document.getElementById("stay-result-count");

let selectedHotelId = null;

const mumbaiStayCatalog = [
  { id: 1001, name: "The Taj Mahal Palace", type: "hotel", area: "Colaba", price_per_night: 25000, rating: 4.8, trust_score: 9.5, best_for: "First-time visitors and luxury stays", description: "Iconic luxury stay in Colaba, close to major South Mumbai attractions." },
  { id: 1002, name: "The Oberoi Mumbai", type: "hotel", area: "South Mumbai", price_per_night: 22000, rating: 4.7, trust_score: 9.4, best_for: "Luxury and sightseeing", description: "Premium stay near Marine Drive and major South Mumbai attractions." },
  { id: 1003, name: "The St. Regis Mumbai", type: "hotel", area: "Lower Parel", price_per_night: 18000, rating: 4.7, trust_score: 9.2, best_for: "Luxury and nightlife", description: "Luxury hotel in Lower Parel with convenient access to shopping and dining." },
  { id: 1004, name: "Taj Lands End", type: "hotel", area: "Bandra", price_per_night: 16000, rating: 4.6, trust_score: 9.1, best_for: "Bandra and sea-facing stays", description: "Premium Bandra stay suitable for leisure and city exploration." },
  { id: 1005, name: "Trident Nariman Point", type: "hotel", area: "South Mumbai", price_per_night: 14000, rating: 4.6, trust_score: 9.0, best_for: "Marine Drive and sightseeing", description: "Premium stay near Marine Drive and South Mumbai landmarks." },
  { id: 1006, name: "JW Marriott Mumbai Juhu", type: "hotel", area: "Juhu", price_per_night: 15000, rating: 4.6, trust_score: 9.0, best_for: "Beach and leisure", description: "Premium Juhu stay close to the beach and entertainment areas." },
  { id: 1007, name: "Four Seasons Hotel Mumbai", type: "hotel", area: "Lower Parel", price_per_night: 17000, rating: 4.6, trust_score: 9.1, best_for: "Luxury and business", description: "Luxury stay with convenient access to central business areas." },
  { id: 1008, name: "ITC Grand Central", type: "hotel", area: "Lower Parel", price_per_night: 11000, rating: 4.5, trust_score: 8.9, best_for: "Business and city exploration", description: "Premium hotel with convenient access to central Mumbai." },
  { id: 1009, name: "Residency Hotel Fort", type: "hotel", area: "South Mumbai", price_per_night: 3500, rating: 4.4, trust_score: 8.6, best_for: "Sightseeing on a mid-range budget", description: "Practical stay for exploring Fort, Colaba and nearby attractions." },
  { id: 1010, name: "Fariyas Hotel Mumbai", type: "hotel", area: "South Mumbai", price_per_night: 5000, rating: 4.2, trust_score: 8.2, best_for: "Families and sightseeing", description: "Mid-range option for travellers exploring South Mumbai." },
  { id: 1011, name: "Hotel Marine Plaza", type: "hotel", area: "South Mumbai", price_per_night: 6500, rating: 4.3, trust_score: 8.4, best_for: "Marine Drive", description: "Stay near Marine Drive with convenient access to South Mumbai." },
  { id: 1012, name: "President Mumbai", type: "hotel", area: "South Mumbai", price_per_night: 7000, rating: 4.4, trust_score: 8.5, best_for: "Business and leisure", description: "Established hotel option in South Mumbai." },
  { id: 1013, name: "Zostel Mumbai", type: "hostel", area: "South Mumbai", price_per_night: 900, rating: 4.2, trust_score: 7.5, best_for: "Budget and solo travellers", description: "Affordable hostel-style stay for budget-conscious travellers." },
  { id: 1014, name: "Mumbai Backpackers Hostel", type: "hostel", area: "Andheri", price_per_night: 700, rating: 4.1, trust_score: 7.2, best_for: "Backpackers", description: "Low-cost hostel-style accommodation for short stays." },
  { id: 1015, name: "Bandra West Apartment", type: "apartment", area: "Bandra", price_per_night: 3200, rating: 4.4, trust_score: 8.3, best_for: "Cafes, nightlife and longer stays", description: "Private apartment-style accommodation in Bandra." },
  { id: 1016, name: "Juhu Beach Apartment", type: "apartment", area: "Juhu", price_per_night: 4000, rating: 4.3, trust_score: 8.1, best_for: "Beach and relaxed stays", description: "Apartment-style stay close to Juhu's leisure areas." },
  { id: 1017, name: "Colaba Heritage Apartment", type: "apartment", area: "Colaba", price_per_night: 4500, rating: 4.4, trust_score: 8.2, best_for: "Sightseeing", description: "Apartment-style option close to Colaba attractions." },
  { id: 1018, name: "Andheri Private Apartment", type: "apartment", area: "Andheri", price_per_night: 2500, rating: 4.2, trust_score: 7.9, best_for: "Airport access and budget", description: "Practical apartment-style stay in Andheri." },
  { id: 1019, name: "BKC Serviced Apartment", type: "serviced apartment", area: "BKC", price_per_night: 5500, rating: 4.4, trust_score: 8.5, best_for: "Business travellers", description: "Serviced apartment option near Mumbai's business district." },
  { id: 1020, name: "Powai Serviced Apartment", type: "serviced apartment", area: "Powai", price_per_night: 4200, rating: 4.3, trust_score: 8.2, best_for: "Longer stays and business", description: "Comfortable serviced-apartment style option in Powai." },
  { id: 1021, name: "Andheri Guest House", type: "guest house", area: "Andheri", price_per_night: 1800, rating: 4.0, trust_score: 7.6, best_for: "Budget travellers", description: "Simple guest-house option for short stays." },
  { id: 1022, name: "Near Airport Business Stay", type: "guest house", area: "Near Airport", price_per_night: 2200, rating: 4.1, trust_score: 7.8, best_for: "Airport transit", description: "Convenient budget-oriented stay for travellers using Mumbai airport." }
];

function getStayCatalog() {
  const databaseStays = Array.isArray(DATA.hotels) ? DATA.hotels : [];
  if (!city || String(city.name).toLowerCase() !== "mumbai") return databaseStays;

  const existingIds = new Set(databaseStays.map(stay => Number(stay.id)));
  const curated = mumbaiStayCatalog.filter(stay => !existingIds.has(Number(stay.id)));
  return [...databaseStays, ...curated];
}

function getStayBudget(price) {
  if (price < 1500) return "budget";
  if (price < 5000) return "mid";
  if (price < 12000) return "premium";
  return "luxury";
}

function calculateStayMatch(stay) {
  let score = 60;
  score += Math.round(Number(stay.rating || 0) * 4);
  score += Math.round(Number(stay.trust_score || 0) * 1.5);

  const selectedArea = stayAreaFilter ? stayAreaFilter.value : "all";
  if (selectedArea !== "all" && stay.area === selectedArea) score += 12;

  const selectedType = stayTypeFilter ? stayTypeFilter.value : "all";
  if (selectedType !== "all" && stay.type === selectedType) score += 10;

  const selectedBudget = stayBudgetFilter ? stayBudgetFilter.value : "all";
  if (selectedBudget !== "all" && getStayBudget(Number(stay.price_per_night)) === selectedBudget) score += 12;

  return Math.min(99, Math.max(50, score));
}

function loadHotels() {
  const grid = document.getElementById("hotel-list");
  if (!grid) return;

  const stays = getStayCatalog();
  const selectedArea = stayAreaFilter ? stayAreaFilter.value : "all";
  const selectedType = stayTypeFilter ? stayTypeFilter.value : "all";
  const selectedBudget = stayBudgetFilter ? stayBudgetFilter.value : "all";

  let filtered = stays.filter(stay => {
    const areaMatch = selectedArea === "all" || stay.area === selectedArea;
    const typeMatch = selectedType === "all" || String(stay.type).toLowerCase() === selectedType;
    const budgetMatch = selectedBudget === "all" || getStayBudget(Number(stay.price_per_night)) === selectedBudget;
    return areaMatch && typeMatch && budgetMatch;
  });

  filtered = filtered
    .map(stay => ({ ...stay, matchScore: calculateStayMatch(stay) }))
    .sort((a, b) => b.matchScore - a.matchScore);

  if (stayResultCount) {
    stayResultCount.textContent = `${filtered.length} ${filtered.length === 1 ? "stay" : "stays"}`;
  }

  grid.innerHTML = "";

  if (filtered.length === 0) {
    grid.innerHTML = `<div class="stay-empty"><h3>No matching stays</h3><p>Try changing the area, stay type or budget.</p></div>`;
    return;
  }

  filtered.forEach(stay => {
    const card = document.createElement("article");
    card.className = "hotel-card stay-card clickable";

    card.innerHTML = `
      <div class="stay-card-top">
        <span class="stay-type">${formatStayType(stay.type)}</span>
        <span class="stay-match">${stay.matchScore}% match</span>
      </div>
      <h3>${stay.name}</h3>
      <p class="stay-location">${stay.area}</p>
      <div class="stay-rating"><strong>${stay.rating}</strong><span>rating</span></div>
      <div class="stay-price">From <strong>₹${Number(stay.price_per_night).toLocaleString()}</strong> / night</div>
      <p class="stay-best-for">Best for: ${stay.best_for}</p>
      <button class="stay-view-btn" type="button">View stay</button>
    `;

    card.addEventListener("click", () => openHotel(stay.id));
    grid.appendChild(card);
  });
}

function formatStayType(type) {
  const value = String(type || "").toLowerCase();
  const labels = {
    hotel: "Hotel",
    apartment: "Apartment",
    hostel: "Hostel",
    "guest house": "Guest House",
    "serviced apartment": "Serviced Apartment"
  };
  return labels[value] || type;
}

function openHotel(hotelId) {
  selectedHotelId = Number(hotelId);
  const listEl = document.getElementById("hotel-list");
  if (listEl) listEl.classList.add("hidden");
  if (hotelDetail) hotelDetail.classList.remove("hidden");
  if (listingSortWrap) listingSortWrap.classList.remove("hidden");
  renderHotelListings();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderHotelListings() {
  if (selectedHotelId === null) return;

  const stays = getStayCatalog();
  const hotel = stays.find(stay => Number(stay.id) === selectedHotelId);
  if (!hotel) {
    if (hotelListings) hotelListings.innerHTML = "<p>Stay not found.</p>";
    return;
  }

  let listings = (DATA.hotel_listings || {})[String(selectedHotelId)] || [];

  if (listings.length === 0 && hotel.id >= 1000) {
    listings = createBookingOptions(hotel);
  }

  listings = [...listings];

  const sort = listingSort ? listingSort.value : "website";
  if (sort === "price") {
    listings.sort((a, b) => Number(a.price_per_night) - Number(b.price_per_night));
  } else if (sort === "rating") {
    listings.sort((a, b) => Number(b.rating || 0) - Number(a.rating || 0));
  } else {
    listings.sort((a, b) => String(a.website).localeCompare(String(b.website)));
  }

  const match = calculateStayMatch(hotel);

  if (hotelDetailContent) {
    hotelDetailContent.innerHTML = `
      <div class="hotel-summary stay-detail-card">
        <div class="stay-detail-top">
          <div>
            <span class="stay-type">${formatStayType(hotel.type)}</span>
            <h2>${hotel.name}</h2>
            <p class="stay-location">${hotel.area}, Mumbai</p>
          </div>
          <div class="detail-match">
            <strong>${match}%</strong>
            <span>MumbAI Match</span>
          </div>
        </div>

        <div class="detail-rating">
          <strong>${hotel.rating}</strong>
          <span>rating</span>
          <span class="detail-separator">·</span>
          <span>Trust ${hotel.trust_score}/10</span>
        </div>

        <div class="detail-price">
          From <strong>₹${Number(hotel.price_per_night).toLocaleString()}</strong> / night
        </div>

        <p class="stay-description">${hotel.description}</p>

        <div class="stay-reason">
          <strong>Why MumbAI recommends it</strong>
          <p>${getStayRecommendationReason(hotel, match)}</p>
        </div>

        <div class="stay-best-box">
          <span>Best for</span>
          <strong>${hotel.best_for}</strong>
        </div>
      </div>
    `;
  }

  if (hotelListings) {
    hotelListings.innerHTML = listings.length
      ? listings.map(listing => createListingCard(listing)).join("")
      : `<div class="stay-empty"><p>No booking options are stored for this stay yet.</p></div>`;

    hotelListings.querySelectorAll(".listing-button").forEach(button => {
      button.addEventListener("click", event => {
        event.stopPropagation();
        const url = button.dataset.url;
        if (url) window.open(url, "_blank", "noopener,noreferrer");
      });
    });
  }
}

function createBookingOptions(hotel) {
  const encoded = encodeURIComponent(`${hotel.name}, Mumbai`);
  return [
    { website: "Booking.com", price_per_night: hotel.price_per_night, rating: hotel.rating, booking_url: `https://www.booking.com/searchresults.html?ss=${encoded}` },
    { website: "Agoda", price_per_night: Math.round(hotel.price_per_night * 0.98), rating: hotel.rating, booking_url: `https://www.agoda.com/search?textToSearch=${encoded}` },
    { website: "Expedia", price_per_night: Math.round(hotel.price_per_night * 1.02), rating: hotel.rating, booking_url: `https://www.expedia.com/Hotel-Search?destination=${encoded}` }
  ];
}

function createListingCard(listing) {
  return `
    <div class="hotel-card listing-card">
      <div class="listing-top">
        <h4>${listing.website}</h4>
        <span class="listing-rating">${listing.rating || "—"}</span>
      </div>
      <div class="meta">
        From <strong>₹${Number(listing.price_per_night).toLocaleString()}</strong> / night
      </div>
      <button class="secondary-btn listing-button" type="button" data-url="${listing.booking_url || ""}">
        View booking options
      </button>
    </div>
  `;
}

function getStayRecommendationReason(hotel, match) {
  const area = hotel.area;
  const budget = getStayBudget(Number(hotel.price_per_night));

  if (area === "South Mumbai" || area === "Colaba") {
    return `This stay is well suited for exploring South Mumbai and its major attractions. Its rating, location and price profile give it a ${match}% match.`;
  }
  if (area === "Bandra" || area === "Juhu") {
    return `This stay is a good fit for travellers interested in leisure, dining and Mumbai's western neighbourhoods. MumbAI gives it a ${match}% match.`;
  }
  if (budget === "budget") {
    return `This option is suitable for travellers prioritising affordability while still maintaining a useful rating. MumbAI gives it a ${match}% match.`;
  }
  if (hotel.type === "serviced apartment") {
    return `The apartment format makes this option suitable for longer or business-oriented stays. Its overall profile gives it a ${match}% match.`;
  }
  return `MumbAI considers its rating, price, location and stay type when calculating this ${match}% match.`;
}

const backToStays = document.getElementById("back-to-stays");
if (backToStays) {
  backToStays.addEventListener("click", () => {
    if (hotelDetail) hotelDetail.classList.add("hidden");
    const listEl = document.getElementById("hotel-list");
    if (listEl) listEl.classList.remove("hidden");
    if (listingSortWrap) listingSortWrap.classList.add("hidden");
    selectedHotelId = null;
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

if (listingSort) {
  listingSort.addEventListener("change", () => renderHotelListings());
}

// Find stays button + back button
const findStaysBtn = document.getElementById("find-stays-btn");
if (findStaysBtn) {
  findStaysBtn.addEventListener("click", () => {
    document.getElementById("stays-intro").classList.add("hidden");
    document.getElementById("stays-result").classList.remove("hidden");
    loadHotels();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

const staysBackBtn = document.getElementById("stays-back-btn");
if (staysBackBtn) {
  staysBackBtn.addEventListener("click", () => {
    document.getElementById("stays-result").classList.add("hidden");
    document.getElementById("stays-intro").classList.remove("hidden");
    const listEl = document.getElementById("hotel-list");
    if (listEl) listEl.classList.remove("hidden");
    if (hotelDetail) hotelDetail.classList.add("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

// ============================================================
// SMART FOOD FINDER — TOPSIS
// ============================================================

const foodPlaces = [
  { name: "Kofuku", area: "Juhu", cuisine: ["japanese", "asian"], dietary: ["jain", "vegetarian"], price: 750, rating: 4.3, googleUrl: "https://www.google.com/maps/search/?api=1&query=Kofuku+Juhu+Mumbai" },
  { name: "Chin Chin Chu", area: "Juhu", cuisine: ["chinese", "japanese", "asian"], dietary: ["jain", "vegetarian"], price: 800, rating: 4.3, googleUrl: "https://www.google.com/maps/search/?api=1&query=Chin+Chin+Chu+Juhu+Mumbai" },
  { name: "Ping's Cafe Orient", area: "Lower Parel", cuisine: ["chinese", "thai", "asian"], dietary: ["jain", "vegetarian"], price: 700, rating: 4.2, googleUrl: "https://www.google.com/maps/search/?api=1&query=Pings+Cafe+Orient+Lower+Parel+Mumbai" },
  { name: "SAZ Cafe", area: "Lower Parel", cuisine: ["italian", "continental", "asian"], dietary: ["jain", "vegetarian"], price: 800, rating: 4.2, googleUrl: "https://www.google.com/maps/search/?api=1&query=SAZ+Cafe+Lower+Parel+Mumbai" },
  { name: "One8 Commune Juhu", area: "Juhu", cuisine: ["italian", "mexican", "asian", "continental"], dietary: ["jain", "vegetarian"], price: 1000, rating: 4.2, googleUrl: "https://www.google.com/maps/search/?api=1&query=One8+Commune+Juhu+Mumbai" },
  { name: "Kyma", area: "Bandra", cuisine: ["asian", "continental"], dietary: ["jain", "vegetarian"], price: 900, rating: 4.3, googleUrl: "https://www.google.com/maps/search/?api=1&query=Kyma+Bandra+Mumbai" },
  { name: "Khyber", area: "Kala Ghoda", cuisine: ["indian", "mughlai"], dietary: ["vegetarian"], price: 1200, rating: 4.4, googleUrl: "https://www.google.com/maps/search/?api=1&query=Khyber+Kala+Ghoda+Mumbai" },
  { name: "Trishna", area: "Kala Ghoda", cuisine: ["seafood", "indian"], dietary: ["seafood"], price: 1500, rating: 4.4, googleUrl: "https://www.google.com/maps/search/?api=1&query=Trishna+Kala+Ghoda+Mumbai" },
  { name: "Mahesh Lunch Home", area: "Colaba", cuisine: ["seafood", "indian"], dietary: ["seafood"], price: 1200, rating: 4.2, googleUrl: "https://www.google.com/maps/search/?api=1&query=Mahesh+Lunch+Home+Colaba+Mumbai" },
  { name: "Gajalee", area: "Andheri", cuisine: ["seafood", "indian"], dietary: ["seafood", "vegetarian"], price: 1100, rating: 4.4, googleUrl: "https://www.google.com/maps/search/?api=1&query=Gajalee+Andheri+Mumbai" },
  { name: "Prithvi Cafe", area: "Juhu", cuisine: ["indian", "continental"], dietary: ["vegetarian"], price: 600, rating: 4.4, googleUrl: "https://www.google.com/maps/search/?api=1&query=Prithvi+Cafe+Juhu+Mumbai" },
  { name: "Cafe Madras", area: "Dadar", cuisine: ["indian"], dietary: ["vegetarian", "jain"], price: 600, rating: 4.4, googleUrl: "https://www.google.com/maps/search/?api=1&query=Cafe+Madras+Dadar+Mumbai" }
];

function getFoodBudgetRange(value) {
  if (value === "500-750") return { min: 500, max: 750 };
  if (value === "750-1000") return { min: 750, max: 1000 };
  if (value === "1000-1500") return { min: 1000, max: 1500 };
  return { min: 1500, max: Infinity };
}

function topsisFood(places, weights) {
  if (!places.length) return [];
  const criteria = ["area", "diet", "cuisine", "budget", "rating"];

  const matrix = places.map(p => criteria.map(c => p.criteria[c]));
  const denom = criteria.map((_, j) => {
    let s = 0;
    for (let i = 0; i < matrix.length; i++) s += matrix[i][j] * matrix[i][j];
    return Math.sqrt(s) || 1;
  });
  const norm = matrix.map(row => row.map((v, j) => v / denom[j]));

  const w = criteria.map(c => weights[c]);
  const weighted = norm.map(row => row.map((v, j) => v * w[j]));

  const ideal = criteria.map((_, j) => Math.max(...weighted.map(row => row[j])));
  const antiIdeal = criteria.map((_, j) => Math.min(...weighted.map(row => row[j])));

  return places.map((p, i) => {
    let dPlus = 0, dMinus = 0;
    for (let j = 0; j < criteria.length; j++) {
      dPlus += (weighted[i][j] - ideal[j]) ** 2;
      dMinus += (weighted[i][j] - antiIdeal[j]) ** 2;
    }
    dPlus = Math.sqrt(dPlus);
    dMinus = Math.sqrt(dMinus);
    const closeness = dMinus / (dPlus + dMinus || 1);
    return { ...p, topsisScore: closeness, score: Math.round(closeness * 100) };
  }).sort((a, b) => b.topsisScore - a.topsisScore);
}

const findFoodButton = document.getElementById("find-food-btn");
if (findFoodButton) {
  findFoodButton.addEventListener("click", () => {
    const area = document.getElementById("food-area").value;
    const diet = document.getElementById("food-diet").value;
    const cuisine = document.getElementById("food-cuisine").value;
    const budget = document.getElementById("food-budget").value;
    const range = getFoodBudgetRange(budget);

    const candidates = foodPlaces.map(place => {
      const areaScore = area === "all" ? 0.5 : (place.area.toLowerCase() === area.toLowerCase() ? 1 : 0.15);
      const dietScore = diet === "any" ? 0.5 : (place.dietary.includes(diet) ? 1 : 0.2);
      const cuisineScore = cuisine === "any" ? 0.5 : (place.cuisine.includes(cuisine) ? 1 : 0.15);
      const inBudget = place.price >= range.min && place.price <= (range.max === Infinity ? 1e9 : range.max);
      const budgetScore = inBudget ? 1 : 0.2;
      const ratingScore = Math.max(0, Math.min(1, (place.rating - 3) / 2));

      const reasons = [];
      if (areaScore === 1) reasons.push("Area match");
      if (dietScore === 1) reasons.push("Dietary match");
      if (cuisineScore === 1) reasons.push("Cuisine match");
      if (budgetScore === 1) reasons.push("Within budget");

      return {
        ...place,
        criteria: { area: areaScore, diet: dietScore, cuisine: cuisineScore, budget: budgetScore, rating: ratingScore },
        reasons
      };
    });

    const weights = { area: 0.25, diet: 0.20, cuisine: 0.20, budget: 0.20, rating: 0.15 };
    const ranked = topsisFood(candidates, weights).slice(0, 6);

    const container = document.getElementById("food-result");
    const intro = document.getElementById("food-intro");

    if (!ranked.length) {
      intro.classList.add("hidden");
      container.innerHTML = `<div class="result-summary"><strong>No strong matches found.</strong><p>Try a different area, cuisine, dietary preference or budget.</p></div>`;
      container.classList.remove("hidden");
      return;
    }

    intro.classList.add("hidden");

    container.innerHTML = `
      <div class="food-results-header">
        <button id="food-back-btn" class="food-back-btn" type="button">← Change filters</button>
        <h3>Best food matches</h3>
        <p>Ranked by closeness to the ideal combination of area, diet, cuisine, budget and rating.</p>
      </div>

      <div class="food-card-grid">
        ${ranked.map(place => `
          <div class="food-card">
            <div class="food-card-top">
              <div>
                <h3>${place.name}</h3>
                <p class="food-area">${place.area}, Mumbai</p>
              </div>
              <div class="food-score">${place.score}%<small>match</small></div>
            </div>

            <div class="food-tags">
              <span>${place.cuisine.map(x => x.charAt(0).toUpperCase() + x.slice(1)).join(" · ")}</span>
            </div>

            <div class="food-price">Typical spend: ₹${place.price.toLocaleString("en-IN")} per person</div>

            <div class="food-reasons">
              ${place.reasons.map(reason => `<span>${reason}</span>`).join("")}
            </div>

            <a class="food-google-btn" href="${place.googleUrl}" target="_blank" rel="noopener noreferrer">View on Google</a>
          </div>
        `).join("")}
      </div>
    `;

    container.classList.remove("hidden");
    container.scrollIntoView({ behavior: "smooth", block: "start" });

    document.getElementById("food-back-btn").addEventListener("click", () => {
      container.classList.add("hidden");
      container.innerHTML = "";
      intro.classList.remove("hidden");
    });
  });
}

// ============================================================
// WEATHER
// ============================================================

async function loadWeather() {
  const output = document.getElementById("weather-result");
  if (!output) return;

  try {
    const response = await fetch(`/api/weather?city_id=${city.id}`);
    const data = await response.json();

    if (data.error || !data.current_weather) {
      output.innerHTML = `<div class="weather-empty">Weather data unavailable.</div>`;
      return;
    }

    const cur = data.current_weather;
    const hourly = data.hourly || {};

    const codeMap = {
      0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
      45: "Fog", 48: "Fog", 51: "Light drizzle", 53: "Drizzle",
      61: "Light rain", 63: "Rain", 65: "Heavy rain",
      71: "Light snow", 73: "Snow", 75: "Heavy snow",
      80: "Rain showers", 81: "Rain showers", 82: "Heavy showers",
      95: "Thunderstorm", 96: "Thunderstorm", 99: "Thunderstorm"
    };
    const condition = codeMap[cur.weathercode] || "—";

    const nowHour = cur.time.slice(0, 13);
    const idx = (hourly.time || []).findIndex(t => t.startsWith(nowHour));
    const humidity = idx >= 0 ? hourly.relative_humidity_2m[idx] : "—";
    const rainChance = idx >= 0 ? hourly.precipitation_probability[idx] : "—";

    let hoursHtml = "";
    if (idx >= 0) {
      hoursHtml = hourly.time
        .slice(idx, idx + 8)
        .map((t, i) => {
          const hour = new Date(t).toLocaleTimeString("en-IN", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          });
          const temp = Math.round(hourly.temperature_2m[idx + i]);
          const rain = hourly.precipitation_probability[idx + i];
          return `
            <div class="weather-hour">
              <span class="weather-hour-time">${hour}</span>
              <span class="weather-hour-temp">${temp}°</span>
              <span class="weather-hour-rain">${rain}%</span>
            </div>
          `;
        })
        .join("");
    }

    output.innerHTML = `
      <div class="weather-current-card">
        <div class="weather-temp-hero">
          <span class="weather-temp-value">${Math.round(cur.temperature)}°C</span>
          <span class="weather-temp-condition">${condition}</span>
        </div>

        <div class="weather-chip-row">
          <div class="weather-chip">
            <span class="weather-chip-label">Wind</span>
            <span class="weather-chip-value">${cur.windspeed} km/h</span>
          </div>
          <div class="weather-chip">
            <span class="weather-chip-label">Humidity</span>
            <span class="weather-chip-value">${humidity}%</span>
          </div>
          <div class="weather-chip">
            <span class="weather-chip-label">Rain</span>
            <span class="weather-chip-value">${rainChance}%</span>
          </div>
        </div>
      </div>

      <div class="weather-hourly-card">
        <span class="weather-section-label">Next 8 hours</span>
        <div class="weather-hourly-row">
          ${hoursHtml}
        </div>
      </div>
    `;
  } catch (err) {
    output.innerHTML = `<div class="weather-empty">Could not load weather.</div>`;
  }
}

// ============================================================
// Rule-based Assistant
// ============================================================

const chatWindow = document.getElementById("chat-window");

function addChatMessage(text, sender) {
  if (!chatWindow) return;
  const div = document.createElement("div");
  div.className = `chat-msg ${sender}`;
  div.textContent = text;
  chatWindow.appendChild(div);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function getAssistantReply(message) {
  const text = message.toLowerCase().trim();

  if (/^(hi|hello|hey|namaste|yo|good morning|good evening|good afternoon)[!.,\s]*$/.test(text)) {
    return `Hi! Ask me about food, weather, stays, or what to explore in Mumbai.`;
  }

  if (/(how are you|how's it going|what's up|sup)\b/.test(text)) {
    return `All good — ready to help. What are you looking for?`;
  }

  if (/(weather|rain|temperature|hot|cold|humid|forecast|climate)/.test(text)) {
    const el = document.querySelector("#weather-result .weather-temp-value");
    const condEl = document.querySelector("#weather-result .weather-temp-condition");
    if (el && condEl && el.textContent.trim()) {
      return `Right now in Mumbai: ${el.textContent} and ${condEl.textContent.toLowerCase()}. Check the Weather tab for the next few hours.`;
    }
    return `Mumbai's weather is live on the Weather tab — temperature, humidity, rain chance, and the next 8 hours.`;
  }

  if (/(food|eat|restaurant|hungry|cuisine|halal|jain|vegetarian|seafood|dinner|lunch|breakfast)/.test(text)) {
    const dietMatch = /(halal|jain|vegetarian|seafood|no.?pork)/.exec(text);
    const areaMatch = /(colaba|bandra|juhu|andheri|dadar|lower parel|kala ghoda|worli|grant road|malad)/.exec(text);

    let matches = foodPlaces.slice();

    if (dietMatch) {
      const d = dietMatch[0].toLowerCase();
      matches = matches.filter(p => p.dietary.some(x => x.toLowerCase().includes(d)));
    }
    if (areaMatch) {
      const a = areaMatch[0].toLowerCase();
      matches = matches.filter(p => p.area.toLowerCase().includes(a));
    }

    if (matches.length === 0) {
      return `I couldn't find a place matching that. Try a different area or cuisine — or open the Food tab to see all options.`;
    }

    const top = matches.slice(0, 3);
    const lines = top.map(p => `• ${p.name} (${p.area}) — ₹${p.price}`).join("\n");
    return `Here are some options:\n${lines}\n\nOpen the Food tab for the full ranked list.`;
  }

  if (/(hotel|stay|hostel|sleep|accommodation|room|book|where to stay)/.test(text)) {
    const budgetMatch = /(budget|cheap|affordable|mid|luxury|premium)/.exec(text);
    const areaMatch = /(colaba|bandra|juhu|andheri|bkc|lower parel|powai)/.exec(text);

    let matches = mumbaiStayCatalog.slice();
    if (budgetMatch) {
      const b = budgetMatch[0].toLowerCase();
      if (/budget|cheap|affordable/.test(b)) {
        matches = matches.filter(s => s.price_per_night < 2000);
      } else if (/mid/.test(b)) {
        matches = matches.filter(s => s.price_per_night >= 2000 && s.price_per_night < 8000);
      } else if (/luxury|premium/.test(b)) {
        matches = matches.filter(s => s.price_per_night >= 12000);
      }
    }
    if (areaMatch) {
      const a = areaMatch[0].toLowerCase();
      matches = matches.filter(s => s.area.toLowerCase().includes(a));
    }

    if (matches.length === 0) {
      return `I couldn't find a stay matching that. Open the Stays tab to browse all options.`;
    }

    const top = matches.slice(0, 3);
    const lines = top.map(s => `• ${s.name} (${s.area}) — ₹${s.price_per_night}/night`).join("\n");
    return `Some stays you might like:\n${lines}\n\nOpen the Stays tab for the full list.`;
  }

  if (/(explore|plan|walk|route|visit|see|afternoon|where should i go|what to do|places)/.test(text)) {
    return `Open the Explore tab — pick a zone like South Mumbai or Bandra, tap the places you want, and we'll sort the shortest walk through them.`;
  }

  if (/(emergency|police|ambulance|hospital|danger|lost|stolen)/.test(text)) {
    return `Emergencies in India:\n• 112 — all emergencies\n• 108 — ambulance\n• 101 — fire\n• 1363 — tourist helpline`;
  }

  return `I can help with food, weather, stays, or places to explore in Mumbai. What would you like?`;
}

const chatSendBtn = document.getElementById("chat-send-btn");
const chatInputEl = document.getElementById("chat-input");

if (chatSendBtn && chatInputEl) {
  chatSendBtn.addEventListener("click", () => {
    const message = chatInputEl.value.trim();
    if (!message) return;
    addChatMessage(message, "user");
    chatInputEl.value = "";
    addChatMessage(getAssistantReply(message), "bot");
  });
  chatInputEl.addEventListener("keydown", event => {
    if (event.key === "Enter") chatSendBtn.click();
  });
}

// ============================================================
// Initialize
// ============================================================

function safeRun(label, fn) {
  try { fn(); } catch (err) { console.error(`MumbAI: ${label} failed to initialize`, err); }
}

safeRun("weather", loadWeather);

safeRun("chat welcome message", () => {
  addChatMessage(`Hi! How can I help you today?`, "bot");
});