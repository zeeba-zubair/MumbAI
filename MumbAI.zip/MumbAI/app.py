import os
import sqlite3

import requests

from flask import Flask, g, render_template, request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "travel.db")

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def rows_to_list(rows):
    return [dict(row) for row in rows]


# ---------------------------------------------------------------------------
# Landing screen
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    db = get_db()

    city_row = db.execute(
        """
        SELECT id, name, state_name
        FROM cities
        WHERE name = 'Mumbai'
          AND country_id = (SELECT id FROM countries WHERE code = 'IN')
        LIMIT 1
        """
    ).fetchone()

    return render_template(
        "index.html",
        default_city=dict(city_row) if city_row else None,
    )


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard/<int:city_id>")
def dashboard(city_id):
    db = get_db()

    city_row = db.execute(
        """
        SELECT *
        FROM cities
        WHERE id = ?
          AND country_id = (SELECT id FROM countries WHERE code = 'IN')
        """,
        (city_id,),
    ).fetchone()

    if not city_row:
        return "City not found", 404

    city = dict(city_row)

    hotels = rows_to_list(
        db.execute(
            "SELECT * FROM hotels WHERE city_id = ? ORDER BY name",
            (city_id,),
        ).fetchall()
    )

    hotel_listings = {}
    for hotel in hotels:
        hotel_listings[str(hotel["id"])] = rows_to_list(
            db.execute(
                "SELECT * FROM hotel_listings WHERE hotel_id = ? ORDER BY website",
                (hotel["id"],),
            ).fetchall()
        )

    dashboard_data = {
        "city": city,
        "hotels": hotels,
        "hotel_listings": hotel_listings,
    }

    return render_template("dashboard.html", dashboard_data=dashboard_data)


# ---------------------------------------------------------------------------
# Weather API (Open-Meteo — no key required)
# ---------------------------------------------------------------------------
@app.route("/api/weather")
def get_weather():
    db = get_db()
    city_id = request.args.get("city_id", type=int)

    if not city_id:
        return {"error": "Missing city_id"}, 400

    city_row = db.execute(
        "SELECT latitude, longitude FROM cities WHERE id = ?",
        (city_id,),
    ).fetchone()

    if not city_row:
        return {"error": "City not found"}, 404

    lat = city_row["latitude"]
    lon = city_row["longitude"]

    try:
        url = (
            f"https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}"
            f"&current_weather=true"
            f"&hourly=temperature_2m,relative_humidity_2m,precipitation_probability"
            f"&timezone=auto"
        )
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}, 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)